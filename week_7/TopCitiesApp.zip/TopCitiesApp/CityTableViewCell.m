//
//  CityTableViewCell.m
//  TopCitiesApp
//
//  Created by Ronald Rivera on 9/22/15.
//  Copyright (c) 2015 Ron Rivera. All rights reserved.
//

#import "CityTableViewCell.h"

@implementation CityTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
