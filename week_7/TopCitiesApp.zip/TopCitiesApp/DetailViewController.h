//
//  DetailViewController.h
//  TopCitiesApp
//
//  Created by Ronald Rivera on 9/22/15.
//  Copyright (c) 2015 Ron Rivera. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "City.h"

@interface DetailViewController : UIViewController

@property (nonatomic, weak)IBOutlet UILabel *populationLabel;
@property (nonatomic, weak)IBOutlet UIImageView *cityImageView;
@property (nonatomic, weak)IBOutlet UITextView *pointsOfInterestTextView;
@property (nonatomic, strong) City *city;

@end
