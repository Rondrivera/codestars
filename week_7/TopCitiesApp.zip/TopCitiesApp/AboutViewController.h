//
//  AboutViewController.h
//  TopCitiesApp
//
//  Created by Ronald Rivera on 9/23/15.
//  Copyright (c) 2015 Ron Rivera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIWebView *webView;

@end
