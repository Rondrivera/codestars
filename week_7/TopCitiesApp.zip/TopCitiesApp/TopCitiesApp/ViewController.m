//
//  ViewController.m
//  TopCitiesApp
//
//  Created by Ronald Rivera on 9/22/15.
//  Copyright (c) 2015 Ron Rivera. All rights reserved.
//

#import "ViewController.h"
#import "CityTableViewCell.h"
#import "DetailViewController.h"
#import "City.h"

@implementation ViewController
{
    NSArray *cities;
    NSArray *searchResults;
    UISearchController *searchController;

}
- (void)viewDidLoad {
    [super viewDidLoad];
    //Initialize the cities array
    City *city1 = [City new];
    city1.name = @"Austin";
    city1.population = @"885,000";
    city1.image = @"austin.jpg";
    //city1.pointsOfInterest = [NSArray arrayWithObjects:@"Clean air", @"Good food", @"Green city", @"Most amount of outdoor activities", nil];
    
    
    City *city2 = [City new];
    city2.name = @"Chicago";
    city2.population = @"2,719,000";
    city2.image = @"chicago.jpg";
    //city2.pointsOfInterest = [NSArray arrayWithObjects:@"Clean air", @"Many museums in the area", @"Home to many great sports teams", @"Beautiful architecture", nil];
    
    
    City *city3 = [City new];
    city3.name = @"Denver";
    city3.population = @"650,000";
    city3.image = @"denver.jpg";
    //city3.pointsOfInterest = [NSArray arrayWithObjects:@"Clean air", @"Home venue of Red Rocks", @"Downtown area is centric to everything", @"Most amount of outdoor activities", nil];
    
    
    City *city4 = [City new];
    city4.name = @"Miami";
    city4.population = @"418,000";
    city4.image = @"miami.jpg";
    //city4.pointsOfInterest = [NSArray arrayWithObjects:@"Great Nightlife", @"Good food", @"Pleasant year around weather", @"Most amount of outdoor activities", nil];
    
    City *city5 = [City new];
    city5.name = @"New York City";
    city5.population = @"9,000,000";
    city5.image = @"newyorkcity.jpg";
    //city5.pointsOfInterest = [NSArray arrayWithObjects:@"Clean air", @"Thousands or bars and clubs to choose from", @"So many museums and places of interest to visit", @"Beautiful people come visit", nil];
    
    City *city6 = [City new];
    city6.name = @"Orlando";
    city6.population = @"256,000";
    city6.image = @"orlando.jpg";
    //city6.pointsOfInterest = [NSArray arrayWithObjects:@"Close to Disney World", @"Good food", @"Many golf courses to play at", @"Great place for retirement", nil];
    
    
    City *city7 = [City new];
    city7.name = @"Portland";
    city7.population = @"650,000";
    city7.image = @"portland.jpg";
    //city7.pointsOfInterest = [NSArray arrayWithObjects:@"Clean air", @"Close to the mountains for Hiking", @"Close to the beach to go swimming", @"Many up and coming singles are moving there", nil];
    
    
    City *city8 = [City new];
    city8.name = @"San Diego";
    city8.population = @"1,356,000";
    city8.image = @"sandiego.jpg";
    //city8.pointsOfInterest = [NSArray arrayWithObjects:@"Beautiful pleasant weather 300 days a year", @"Many beaches to visit", @"Green city", @"Many beachside activities", nil];
    
    City *city9 = [City new];
    city9.name = @"San Francisco";
    city9.population = @"838,000";
    city9.image = @"sanfran.jpg";
    //city9.pointsOfInterest = [NSArray arrayWithObjects:@"Fantastic restaurants", @"Great quality of life", @"Eco friendly city", @"Many different breweries", nil];
    
    
    City *city10 = [City new];
    city10.name = @"Seattle";
    city10.population = @"653,000";
    city10.image = @"seattle.jpg";
    //city10.pointsOfInterest = [NSArray arrayWithObjects:@"Most breweries per capita", @"Biggest diversity of coffee shops", @"Many places to have brunch", @"Headquarters of Amazon and Starbucks", nil];
    
    cities = [NSArray arrayWithObjects:city1, city2, city3, city4, city5,city6, city7, city8, city9, nil];
                    }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(searchController.active) {
        return searchResults.count;
    } else {
        return [cities count];
    }
}
-(UITableViewCell *)tableView: (UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    static NSString *cellIdentifier = @"CityTableViewCell";
    CityTableViewCell *cell = (CityTableViewCell*)
    [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    
    City *city;
    if (searchController.active) {
        city = [searchResults objectAtIndex:indexPath.row];
    } else {
        city = [cities objectAtIndex:indexPath.row];
    }
    
    
    if (cell == nil) {
        cell = [[CityTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.cityLabel.text = city.name;
    cell.thumbnailImageView.image = [UIImage imageNamed:city.image];
    cell.populationLabel.text = city.population;
    
    return cell;
}

-(void)filterContentForSearchText:(NSString *)searchText {
    NSPredicate*resultPredicate = [NSPredicate predicateWithFormat:@"name contains[c]%@", searchText];
    searchResults = [cities filteredArrayUsingPredicate:resultPredicate];
    searchController.searchResultsUpdater = self;
    searchController.dimsBackgroundDuringPresentation = NO;
}
-(void)updateSearchResultsForSearchController:(UISearchController *)searchController {
    [self filterContentForSearchText:searchController.searchBar.text];
    [self.tableView reloadData];
    
}

-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
    NSString *selectedCity = [cities objectAtIndex:indexPath.row];
    UIAlertView *messageAlert = [[UIAlertView alloc]
                                 initWithTitle:@"Row Selected"
                                 message:selectedCity
                                 delegate:nil
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
    [messageAlert show];
    
    //cityChecked[indexPath.row] = YES;
    [tableView deselectRowAtIndexPath: indexPath animated:YES];
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showCityDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        DetailViewController *destViewController = segue.destinationViewController;
        
        City *city;
        if (searchController.active) {
            city = [searchResults objectAtIndex:indexPath.row];
        } else {
            city = [cities objectAtIndex:indexPath.row];
        }
        destViewController.city = city;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
