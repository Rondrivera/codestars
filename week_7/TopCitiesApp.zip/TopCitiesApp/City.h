//
//  City.h
//  TopCitiesApp
//
//  Created by Ronald Rivera on 9/23/15.
//  Copyright (c) 2015 Ron Rivera. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject

@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *population;
@property (nonatomic, strong)NSString *image;
@property (nonatomic, strong)NSString *pointsOfInterest;

@end
