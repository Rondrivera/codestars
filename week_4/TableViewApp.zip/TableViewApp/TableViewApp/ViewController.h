//
//  ViewController.h
//  TableViewApp
//
//  Created by Ronald Rivera on 8/24/15.
//  Copyright (c) 2015 Ron Rivera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>


@end

